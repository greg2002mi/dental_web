from django.contrib.auth.models import Permission

# Define permissions for MainCompany
view_main_company, _ = Permission.objects.get_or_create(codename='view_maincompany')
add_main_company, _ = Permission.objects.get_or_create(codename='add_maincompany')
change_main_company, _ = Permission.objects.get_or_create(codename='change_maincompany')
delete_main_company, _ = Permission.objects.get_or_create(codename='delete_maincompany')

# Define permissions for Department
view_department, _ = Permission.objects.get_or_create(codename='view_department')
add_department, _ = Permission.objects.get_or_create(codename='add_department')
change_department, _ = Permission.objects.get_or_create(codename='change_department')
delete_department, _ = Permission.objects.get_or_create(codename='delete_department')

# Define permissions for VendorCompany
view_vendor_company, _ = Permission.objects.get_or_create(codename='view_vendorcompany')
add_vendor_company, _ = Permission.objects.get_or_create(codename='add_vendorcompany')
change_vendor_company, _ = Permission.objects.get_or_create(codename='change_vendorcompany')
delete_vendor_company, _ = Permission.objects.get_or_create(codename='delete_vendorcompany')

# Define permissions for Forwarder
view_forwarder, _ = Permission.objects.get_or_create(codename='view_forwarder')
add_forwarder, _ = Permission.objects.get_or_create(codename='add_forwarder')
change_forwarder, _ = Permission.objects.get_or_create(codename='change_forwarder')
delete_forwarder, _ = Permission.objects.get_or_create(codename='delete_forwarder')

# Define permissions for Inspector
view_inspector, _ = Permission.objects.get_or_create(codename='view_inspector')
add_inspector, _ = Permission.objects.get_or_create(codename='add_inspector')
change_inspector, _ = Permission.objects.get_or_create(codename='change_inspector')
delete_inspector, _ = Permission.objects.get_or_create(codename='delete_inspector')