"""
URL configuration for pcm project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from users import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('main-companies/', views.main_company_view, name='main_company_view'),
    path('vendor-companies/', views.vendor_company_view, name='vendor_company_view'),
    path('forwarders/', views.forwarder_view, name='forwarder_view'),
    path('inspectors/', views.inspector_view, name='inspector_view'),
]
