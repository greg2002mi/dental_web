import uuid
from django.db import models
from django.utils import timezone
from django.contrib.auth.models import AbstractBaseUser, PermissionsMixin, Group, Permission
from django.utils.translation import gettext_lazy as _
from .managers import CustomUserManager
from phonenumber_field.modelfields import PhoneNumberField


class CustomUser(AbstractBaseUser, PermissionsMixin):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4)
    email = models.EmailField(unique=True)
    last_name = models.CharField(max_length=30)
    first_name = models.CharField(max_length=30)
    telephone = PhoneNumberField(blank=True, null=True) 
    phone = PhoneNumberField(blank=True, null=True) 
    birthday = models.DateField(blank=True, null=True)
    is_staff = models.BooleanField(default=False)
    is_active = models.BooleanField(default=True)
    date_joined = models.DateTimeField(default=timezone.now)
    groups = models.ManyToManyField(Group, blank=True) 
    REQUIRED_FIELDS = []
    USERNAME_FIELD = 'email'
    
    objects = CustomUserManager()
    
    def get_short_name(self):
        return self.email
    
    def __str__(self):
        return self.email
    
    
class MainCompany(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4)
    name = models.CharField(max_length=100, unique=True)
    logo = models.ImageField(default='default.png', upload_to='logo/')
    website = models.CharField(max_length=100, unique=True, blank=True, null=True)
    telephone = PhoneNumberField(blank=True, null=True) 
    
    # Add any additional fields specific to the MainCompany if needed

    def __str__(self):
        return self.name


class Department(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4)
    name = models.CharField(max_length=100)
    main_company = models.ForeignKey(MainCompany, on_delete=models.CASCADE)
    description = models.TextField(max_length=140, blank=True, null=True)

    def __str__(self):
        return self.name


class Vendor(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4)
    name = models.CharField(max_length=100, unique=True)
    logo = models.ImageField(default='default.png', upload_to='logo/')
    website = models.CharField(max_length=100, unique=True, blank=True, null=True)
    telephone = PhoneNumberField(blank=True, null=True)
    email = models.EmailField(unique=True, blank=True, null=True)
    country = models.CharField(max_length=100, blank=True, null=True)
    # Add any additional fields specific to the VendorCompany if needed

    def __str__(self):
        return self.name


class Forwarder(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4)
    name = models.CharField(max_length=100, unique=True)
    logo = models.ImageField(default='default.png', upload_to='logo/')
    website = models.CharField(max_length=100, unique=True, blank=True, null=True)
    telephone = PhoneNumberField(blank=True, null=True) 
    email = models.EmailField(unique=True, blank=True, null=True)
    country = models.CharField(max_length=100, blank=True, null=True)
    # Add any additional fields specific to the Forwarder if needed

    def __str__(self):
        return self.name


class Inspector(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4)
    name = models.CharField(max_length=100, unique=True)
    telephone = PhoneNumberField(blank=True, null=True) 
    email = models.EmailField(unique=True, blank=True, null=True)
    # Add any additional fields specific to the Inspector if needed

    def __str__(self):
        return self.name
    