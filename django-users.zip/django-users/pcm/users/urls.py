from django.urls import path

from . import views

urlpatterns = [
    path("profile", views.profile, name="profile"),
    path("register/", views.register_page, name="register"),
    path("login/", views.login_page, name="login"),
    path("logout/", views.logout_page, name="logout"),
    path("change_password", views.change_password, name="change_password"),
    path("<int:user_id>/avatar_upload", views.avatar_upload, name="avatar_upload"),
    
]