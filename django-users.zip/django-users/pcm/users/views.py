from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.contrib.auth.decorators import user_passes_test
from .models import MainCompany, Vendor, Forwarder, Inspector


@login_required
@user_passes_test(lambda u: u.groups.filter(name='Main Company').exists(), login_url='/')
def main_company_view(request):
    main_companies = MainCompany.objects.all()
    return render(request, 'main_company.html', {'main_companies': main_companies})


@login_required
@user_passes_test(lambda u: u.groups.filter(name='Vendor Company').exists(), login_url='/')
def vendor_company_view(request):
    vendor_companies = Vendor.objects.all()
    return render(request, 'vendor_company.html', {'vendor_companies': vendor_companies})


@login_required
@user_passes_test(lambda u: u.groups.filter(name='Forwarder').exists(), login_url='/')
def forwarder_view(request):
    forwarders = Forwarder.objects.all()
    return render(request, 'forwarder.html', {'forwarders': forwarders})


@login_required
@user_passes_test(lambda u: u.groups.filter(name='Inspector').exists(), login_url='/')
def inspector_view(request):
    inspectors = Inspector.objects.all()
    return render(request, 'inspector.html', {'inspectors': inspectors})
